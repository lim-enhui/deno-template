# fresh project

### Usage

Start the project:

```
deno task start
```

This will watch the project directory and restart as necessary.
